// context/AuthContext.tsx
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import React, { createContext, useContext, useEffect, useState } from "react";
import { Alert } from "react-native";
import { authAPI } from "../../lib/api";

interface User {
  _id: string;
  name: string;
  email: string;
  phone?: string;
  role: "donor" | "ngo" | "admin" | "delivery";
  pushToken?: string;
  lastActiveAt?: string;
  createdAt?: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (params: {
    name: string;
    email: string;
    phone?: string;
    password: string;
    confirmPassword: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
}

const TOKEN_KEY = "@auth_token";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  const getAuthToken = async (): Promise<string | null> => {
    try {
      return await AsyncStorage.getItem(TOKEN_KEY);
    } catch (error) {
      console.error("Error getting auth token:", error);
      return null;
    }
  };

  const setAuthToken = async (value: string): Promise<void> => {
    try {
      await AsyncStorage.setItem(TOKEN_KEY, value);
      setToken(value);
    } catch (error) {
      console.error("Error setting auth token:", error);
    }
  };

  const removeAuthToken = async (): Promise<void> => {
    try {
      await AsyncStorage.removeItem(TOKEN_KEY);
      setToken(null);
    } catch (error) {
      console.error("Error removing auth token:", error);
    }
  };

  const checkAuth = async () => {
    try {
      setIsLoading(true);
      const storedToken = await getAuthToken();

      if (storedToken) {
        try {
          const data = await authAPI.getMe(storedToken);
          setUser(data.user);
          setToken(storedToken);
        } catch (error) {
          console.error("Failed to fetch user data:", error);
          await removeAuthToken();
          setUser(null);
        }
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error("Auth check error:", error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      const data = await authAPI.login(email, password);

      if (data.success && data.token && data.user) {
        await setAuthToken(data.token);
        setUser(data.user);
        router.replace("/(tabs)/");
      } else {
        throw new Error(data.message || "Login failed");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      Alert.alert("Login Error", error.message || "Login failed");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (params: {
    name: string;
    email: string;
    phone?: string;
    password: string;
    confirmPassword: string;
  }) => {
    try {
      setIsLoading(true);

      const data = await authAPI.register(params);

      if (!data.success) {
        throw new Error(data.message || "Registration failed");
      }

      // Auto-login right after successful signup
      const loginData = await authAPI.login(params.email, params.password);

      if (loginData.success && loginData.token && loginData.user) {
        await setAuthToken(loginData.token);
        setUser(loginData.user);
        router.replace("/(tabs)/profile");
      } else {
        throw new Error(loginData.message || "Auto login after signup failed");
      }
    } catch (error: any) {
      console.error("Register error:", error);
      Alert.alert("Registration Error", error.message || "Registration failed");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      await removeAuthToken();
      setUser(null);
      router.replace("/auth/sign-in");
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const value: AuthContextType = {
    user,
    token,
    isLoading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
