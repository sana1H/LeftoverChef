// import { View, Text, Alert } from "react-native";
// import React, { useState } from "react";
// import { Link, useRouter } from "expo-router";
// import CustomButton from "@/components/CustomButton";
// import CustomInput from "@/components/CustomInput";
// import { signIn } from "@/lib/appwrite";

// const SignIn = () => {
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [form, setForm] = useState({ email: "", password: "" });
//   const router = useRouter();

//   const submit = async () => {
//     if (!form.email || !form.password) {
//       return Alert.alert(
//         "Error",
//         "Please enter valid email address & password."
//       );
//     }

//     setIsSubmitting(true);

//     try {
//       await signIn({ email: form.email, password: form.password });
//       Alert.alert("Success", "User signed in successfully.", [
//         {
//           text: "OK",
//           onPress: () => router.replace("/"),
//         },
//       ]);
//     } catch (error: any) {
//       Alert.alert("Error", error.message || "Something went wrong");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <View className="gap-10 bg-white rounded-lg p-5 mt-5">
//       <View className="gap-2">
//         <Text className="text-2xl font-quicksand-bold text-dark-100">
//           Welcome Back! 👋
//         </Text>
//         <Text className="text-base text-gray-600 font-quicksand">
//           Sign in to continue sharing food and making a difference
//         </Text>
//       </View>

//       <CustomInput
//         placeholder="Enter your email"
//         value={form.email}
//         onChangeText={(text) => setForm((prev) => ({ ...prev, email: text }))}
//         label="Email"
//         keyboardType="email-address"
//       />
//       <CustomInput
//         placeholder="Enter your password"
//         value={form.password}
//         onChangeText={(text) =>
//           setForm((prev) => ({ ...prev, password: text }))
//         }
//         label="Password"
//         secureTextEntry={true}
//       />
//       <CustomButton title="Sign In" isLoading={isSubmitting} onPress={submit} />

//       <View className="flex justify-center mt-5 flex-row gap-2">
//         <Text className="base-regular text-gray-600">
//           Don't have an account?
//         </Text>
//         <Link href="/auth/sign-up" className="base-bold text-primary">
//           Sign Up
//         </Link>
//       </View>
//     </View>
//   );
// };

// export default SignIn;


import CustomButton from "@/components/CustomButton";
import CustomInput from "@/components/CustomInput";
import { LinearGradient } from "expo-linear-gradient";
import { Link } from "expo-router";
import React, { useState } from "react";
import { Alert, Text, View } from "react-native";
import { useAuth } from "../context/AuthContext";

const SignIn = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({ email: "", password: "" });
  const { login } = useAuth();

  const submit = async () => {
    if (!form.email || !form.password) {
      return Alert.alert(
        "Error",
        "Please enter valid email address & password."
      );
    }

    setIsSubmitting(true);

    try {
      await login(form.email.trim(), form.password);
    } catch (error: any) {
      Alert.alert("Error", error.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <LinearGradient
      colors={["#ffe6ff", "#f8d0ff", "#f0b8ff"]}
      className="flex-1 justify-center px-5"
    >
      <View className="bg-white/95 rounded-3xl px-5 py-8 shadow-lg shadow-purple-300">
        <View className="gap-2 mb-6">
          <Text className="text-3xl font-quicksand-bold text-[#7e22ce]">
            Welcome back
          </Text>
          <Text className="text-base text-[#6b21a8] font-quicksand">
            Sign in to continue sharing food and spreading kindness.
          </Text>
        </View>

        <View className="gap-4">
          <CustomInput
            placeholder="you@example.com"
            value={form.email}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, email: text }))
            }
            label="Email"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <CustomInput
            placeholder="Enter your password"
            value={form.password}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, password: text }))
            }
            label="Password"
            secureTextEntry={true}
            autoCapitalize="none"
          />
        </View>

        <View className="mt-6">
          <CustomButton
            title="Sign In"
            isLoading={isSubmitting}
            onPress={submit}
          />
        </View>

        <View className="flex justify-center mt-6 flex-row gap-2">
          <Text className="base-regular text-gray-600">
            Don&apos;t have an account?
          </Text>
          <Link href="/auth/sign-up" className="base-bold text-[#ec4899]">
            Sign Up
          </Link>
        </View>
      </View>
    </LinearGradient>
  );
};

export default SignIn;