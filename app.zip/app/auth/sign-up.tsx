// import { View, Text, Alert } from "react-native";
// import React, { useState } from "react";
// import { Link, useRouter } from "expo-router";
// import CustomButton from "@/components/CustomButton";
// import CustomInput from "@/components/CustomInput";
// import { createUser } from "@/lib/appwrite";

// const SignUp = () => {
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [form, setForm] = useState({ name: "", email: "", password: "" });
//   const router = useRouter();

//   const submit = async () => {
//     const { name, email, password } = form;
//     if (!name || !email || !password) {
//       Alert.alert(
//         "Error",
//         "Please enter valid name, email address & password."
//       );
//       return;
//     }

//     setIsSubmitting(true);

//     try {
//       await createUser({ email, password, name });
//       Alert.alert("Success", "Account created successfully!");
//       router.replace("/");
//     } catch (error: any) {
//       Alert.alert("Error", error.message || "Something went wrong");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <View className="gap-10 bg-white rounded-lg p-5 mt-5">
//       <CustomInput
//         placeholder="Enter your name"
//         value={form.name}
//         onChangeText={(text) => setForm((prev) => ({ ...prev, name: text }))}
//         label="Name"
//       />
//       <CustomInput
//         placeholder="Enter your email"
//         value={form.email}
//         onChangeText={(text) => setForm((prev) => ({ ...prev, email: text }))}
//         label="Email"
//         keyboardType="email-address"
//       />
//       <CustomInput
//         placeholder="Enter your password"
//         value={form.password}
//         onChangeText={(text) =>
//           setForm((prev) => ({ ...prev, password: text }))
//         }
//         label="Password"
//         secureTextEntry={true}
//       />
//       <CustomButton title="Sign-Up" isLoading={isSubmitting} onPress={submit} />

//       <View className="flex justify-center mt-5 flex-row gap-2">
//         <Text className="base-regular text-gray-600">
//           Already have an account?
//         </Text>
//         <Link href="/auth/sign-in" className="base-bold text-primary">
//           Sign In
//         </Link>
//       </View>
//     </View>
//   );
// };

// export default SignUp;


import CustomButton from "@/components/CustomButton";
import CustomInput from "@/components/CustomInput";
import { LinearGradient } from "expo-linear-gradient";
import { Link } from "expo-router";
import React, { useState } from "react";
import { Alert, Text, View } from "react-native";
import { useAuth } from "../context/AuthContext";

const SignUp = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const { register } = useAuth();

  const submit = async () => {
    const { name, email, phone, password, confirmPassword } = form;
    if (!name || !email || !password || !confirmPassword) {
      Alert.alert(
        "Error",
        "Please enter name, email, password and confirm password."
      );
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert("Error", "Passwords do not match.");
      return;
    }

    setIsSubmitting(true);

    try {
      await register({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        password,
        confirmPassword,
      });
    } catch (error: any) {
      Alert.alert("Error", error.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <LinearGradient
      colors={["#ffe6ff", "#f8d0ff", "#f0b8ff"]}
      className="flex-1 justify-center px-5"
    >
      <View className="bg-white/95 rounded-3xl px-5 py-8 shadow-lg shadow-purple-300">
        <View className="gap-2 mb-6">
          <Text className="text-3xl font-quicksand-bold text-[#7e22ce]">
            Create an account
          </Text>
          <Text className="text-base text-[#6b21a8] font-quicksand">
            Join LeftoverChef and turn extra food into smiles.
          </Text>
        </View>

        <View className="gap-4">
          <CustomInput
            placeholder="Full name"
            value={form.name}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, name: text }))
            }
            label="Full Name"
          />
          <CustomInput
            placeholder="Phone (optional)"
            value={form.phone}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, phone: text }))
            }
            label="Phone"
            keyboardType="phone-pad"
          />
          <CustomInput
            placeholder="you@example.com"
            value={form.email}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, email: text }))
            }
            label="Email"
            keyboardType="email-address"
          />
          <CustomInput
            placeholder="Create a password"
            value={form.password}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, password: text }))
            }
            label="Password"
            secureTextEntry={true}
          />
          <CustomInput
            placeholder="Confirm password"
            value={form.confirmPassword}
            onChangeText={(text) =>
              setForm((prev) => ({ ...prev, confirmPassword: text }))
            }
            label="Confirm Password"
            secureTextEntry={true}
          />
        </View>

        <View className="mt-6">
          <CustomButton
            title="Sign Up"
            isLoading={isSubmitting}
            onPress={submit}
          />
        </View>

        <View className="flex justify-center mt-6 flex-row gap-2">
          <Text className="base-regular text-gray-600">
            Already have an account?
          </Text>
          <Link href="/auth/sign-in" className="base-bold text-[#ec4899]">
            Sign In
          </Link>
        </View>
      </View>
    </LinearGradient>
  );
};

export default SignUp;